<?php

namespace Mega\SallaVoiceAI\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Mega\SallaVoiceAI\Models\Product;
use Mega\SallaVoiceAI\Models\Store;
use Mega\SallaVoiceAI\Models\VoiceLog;
use Mega\SallaVoiceAI\Services\AIService;
use Mega\SallaVoiceAI\Services\VoiceService;

class VoiceController
{
    public function search(Request $request)
    {
        try {

            $request->validate([
                'audio' => 'required|file',
                'store_id' => 'required|exists:stores,id'
            ]);

            $store = Store::findOrFail($request->store_id);

            // 🎤 Convert voice → text
            $audioPath = $request->file('audio')->getRealPath();
            $text = app(VoiceService::class)->speechToText($audioPath);

            if (!$text) {
                return response()->json([
                    'success' => false,
                    'message' => 'Voice not recognized'
                ]);
            }

            // 🧠 Parse
            $filters = app(AIService::class)->parse($text);

            // 🛍️ Search
            $products = Product::where('store_id', $store->id)
                ->when($filters['price_max'] ?? null,
                    fn($q, $p) => $q->where('price', '<=', $p))
                ->limit(20)
                ->get();

            // 🧾 Log
            VoiceLog::create([
                'store_id' => $store->id,
                'query' => $text,
                'ai_response' => $filters,
                'results_count' => $products->count(),
                'language' => 'ar'
            ]);

            return response()->json([
                'success' => true,
                'spoken_text' => $text,
                'products' => $products
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function detectLanguage($text)
    {
        return preg_match('/[\x{0600}-\x{06FF}]/u', $text) ? 'ar' : 'en';
    }
}