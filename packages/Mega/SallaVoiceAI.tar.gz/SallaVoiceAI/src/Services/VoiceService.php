<?php


namespace Mega\SallaVoiceAI\Services;

use Illuminate\Support\Facades\Http;

class VoiceService
{
    public function speechToText($filePath)
    {
        $apiKey = config('salla-ai.elevenlabs_key');

        if (!$apiKey) {
            throw new \Exception("ElevenLabs API key missing");
        }

        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
        ])->attach(
            'file',
            file_get_contents($filePath),
            'audio.webm'
        )->post('https://api.elevenlabs.io/v1/speech-to-text');

        $data = $response->json();

        // Debug if needed
        // dd($data);

        if (isset($data['text'])) {
            return $data['text'];
        }

        return '';
    }
}