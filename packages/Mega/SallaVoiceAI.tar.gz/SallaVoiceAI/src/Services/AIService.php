<?php
namespace Mega\SallaVoiceAI\Services;

use Illuminate\Support\Facades\Http;

class AIService
{
    public function parse($text)
    {
        $res = Http::withToken('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')
            ->post('https://api.openai.com/v1/chat/completions', [
                'model' => 'gpt-4o-mini',
                'messages' => [
                    ['role'=>'system','content'=>'Extract keywords and price'],
                    ['role'=>'user','content'=>$text]
                ]
            ]);
        dd($res->json());

        return json_decode($res['choices'][0]['message']['content'], true);
    }
}