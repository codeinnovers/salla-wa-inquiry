<?php
return [
    'openai_key' => env('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'),
    'salla_client_id' => env('SALLA_CLIENT_ID'),
    'salla_client_secret' => env('SALLA_CLIENT_SECRET'),
];